<?php

include '../../business/empleadoBusiness.php';
$idEmpleado = $_POST['idEmpleado'];
$empleadoBusiness = new EmpleadoBusiness();
$empleado = $empleadoBusiness->eliminarEmpleado($idEmpleado);

if ($empleado) {
    echo 'Se elimino correactamente!';
} else {
    echo 'No se elimino!';
}
    

