<?php

include '../../business/rolBusiness.php';

$idRol = $_POST['idRol'];

//instancia de business
$telefonoBusiness = new rolBusiness();

//se elimina
$resultado = $telefonoBusiness->deleteRol($idRol);

if ($resultado){
    echo 'Rol eliminado correctamente.';
}  else {
    echo 'No se elimino el rol.';
}

