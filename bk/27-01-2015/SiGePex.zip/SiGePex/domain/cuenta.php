<?php

class cuenta {

    public $idCuenta;
    public $idEmpleado;
    public $numeroCuenta;
    public $nombreBanco;
    public $tipoCuenta;
    public $numeroSimpe;

    public function cuenta($idCuenta, $numeroCuenta, $nombreBanco, $tipoCuenta, $numeroSimpe, $idEmpleado) {
        $this->idCuenta = $idCuenta;
        $this->numeroCuenta = $numeroCuenta;
        $this->nombreBanco = $nombreBanco;
        $this->tipoCuenta = $tipoCuenta;
        $this->numeroSimpe = $numeroSimpe;
        $this->idEmpleado = $idEmpleado;
    }

}

?>
