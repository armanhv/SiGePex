<?php

include '../../data/rolData.php';

class rolBusiness {

    //variables de composicion
    private $rolData;

    //metoso constructor
    public function rolBusiness() {
        $this->rolData = new rolData();
    }

    // metodo que se utiliza para insertar un rol
    public function insertRol($rol) {
        $this->rolData->connect();
        $result = $this->rolData->insertRol($rol);
        $this->rolData->close();
        return $result;
    }

    //metodo que se utiliza pra actualizar un rol
    public function updateRol($rol) {
        $this->rolData->connect();
        $result = $this->rolData->updateRol($rol);
        $this->rolData->close();
        return $result;
    }

    //metodo que se utiliza para eliminar un rol
    public function deleteRol($idRol) {
        $this->rolData->connect();
        $result = $this->rolData->deleteRol($idRol);
        $this->rolData->close();
        return $result;
    }

    //metodo que se utiliza para obtener todos los roles
    public function getRoles() {
        $this->rolData->connect();
        $restul = $this->rolData->getRoles();
        $this->rolData->close();
        return $restul;
    }

}
