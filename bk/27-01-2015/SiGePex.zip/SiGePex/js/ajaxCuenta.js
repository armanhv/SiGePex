/******************* Metodos CRUD para CUENTA ***************************/
function insertarCuenta() {

    var idCuenta = 0;

    var parametros = {
        "idCuenta": idCuenta.value,
        "numeroCuenta": $('#txtNumeroCuenta').val(),
        "nombreBanco": $('#txtNombreBanco').val(),
        "tipoCuenta": $('#cbxTipoCuenta').val(),
        "numeroSimpe": $('#txtnumeroSimpe').val(),
        "idEmpleado": $('#cbxEmpleado').val()
    };

    alert($('#txtNumeroCuenta').val());

    $.ajax({
        data: parametros,
        url: 'insertarCuenta.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerCuentas();
            $("#resultado").html(response);
        }
    });

}

function actualizarCuenta() {

    var idCuenta = document.getElementById("cbxCuentas").value;
    var parametros = {
        "idCuenta": idCuenta,
        "numeroCuenta": $('#txtNumeroCuenta').val(),
        "nombreBanco": $('#txtNombreBanco').val(),
        "tipoCuenta": $('#cbxTipoCuenta').val(),
        "numeroSimpe": $('#txtnumeroSimpe').val(),
        "idEmpleado": $('#cbxEmpleado').val()
    };

    $.ajax({
        data: parametros,
        url: 'actualizarCuenta.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerCuentas();
            $("#resultado").html(response);
        }
    });
}

function borrarCuenta() {
    var idCuenta = document.getElementById("cbxCuentas").value;

    var parametros = {
        "idCuenta": idCuenta
    };

    $.ajax({
        data: parametros,
        url: 'borrarCuenta.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerCuentas();
            $("#resultado").html(response);
        }
    });
}
function obtenerCuentas() {
    $.ajax({
        data: '',
        url: 'obtenerCuentasCuenta.php',
        type: 'post',
        success: function (response) {
            $("#cuentas").html(response);
        }


    });
}

function obtenerEmpleadosCuentas() {
    $.ajax({
        data: '',
        url: 'obtenerEmpleadosCuenta.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}

function cargarCuentas() {
    //Obtener los valores
    var idCuenta = document.getElementById("cbxCuentas").value;

    var parametros = {
        "idCuenta": idCuenta
    };

    $.ajax({
        data: parametros,
        url: 'cargarCamposCuenta.php',
        type: 'post',
        success: function (response) {
            $("#tablaCuenta").html(response);
        }
    });
}

