<?php

include '../../domain/rol.php';

class rolData {

    //Variables 
    private $server;
    private $user;
    private $pass;
    private $dbName;
    private $connection;

    //constructor
    public function rolData() {
        $this->server = "localhost";
        $this->user = "root";
        $this->pass = "";
        $this->dbName = "dbRapiServicios";
    }

    //Metodo para establecer la coneccion
    public function connect() {
        $this->connection = mysqli_connect($this->server, $this->user, $this->pass, $this->dbName);
        return $this->connection;
    }

    //Metodo para cerrar la coneccion
    public function close() {
        mysqli_close($this->connection);
    }

    //Metodo para insertar un rol
    public function insertRol($rol) {
        $resultadoId = mysqli_query($this->connection, "SELECT idRol FROM tbRol ORDER BY idRol DESC LIMIT 1;");
        while ($fila = mysqli_fetch_array($resultadoId)) {
            $idNuevo = $fila['idRol'];
        }
        $idNuevo = $idNuevo + 1;


        $query = "insert into tbRol values (" . $idNuevo . ",'" . $rol->nombreRol . "')";

        $result = mysqli_query($this->connection, $query);

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    //Metodo para eliminara un rol
    public function deleteRol($idRol) {
        $query = "delete from tbRol where idRol=" . $idRol . ";";
        $result = mysqli_query($this->connection, $query);

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    //Metodo para Actualizar un rol
    public function updateRol($rol) {
        $query = "update tbRol set nombreRol='" . $rol->nombreRol
                . "' where idRol =" . $rol->idRol;

        $result = mysqli_query($this->connection, $query);

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    //Metodo para obtener todos los roles
    public function getRoles() {
        $result = mysqli_query($this->connection, "select * from tbRol");
        $arrayRoles = [];

        while ($row = mysqli_fetch_array($result)) {
            $currentRol = new rol($row['idRol'], $row['nombreRol']);
            array_push($arrayRoles, $currentRol);
        }
        return $arrayRoles;
    }

}
