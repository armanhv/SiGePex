<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>     
        <script type="text/javascript" src="../../js/ajaxEmpleado.js"></script>
        <script type="text/javascript" src="../../js/ajaxRol.js"></script>
        <script type="text/javascript" src="../../js/ajaxTelefono.js"></script>  
        <script type="text/javascript" src="../../js/jquery.js"></script>
        <script type="text/javascript" src="../../js/validacion/validarEmail.js"></script>
        <script type="text/javascript" src="../../js/validacion/mascaraTelefono.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('input[type=text]').bind('copy paste cut', function (e) {
                    e.preventDefault();
                });
            });
        </script>
    </head>
    <body style="" onload="obtenerRoles();obtenerEmpleados()">
        <form>
            <p><font size=6>Mantenimiento de  Empleados </font></p>
            <br>        
            <label for="empleados"><font size=5>Empleados:&nbsp;&nbsp;</font></label>  
            <span id="empleados"></span>&nbsp;&nbsp;
            <label for="rol">Rol:&nbsp;&nbsp;</font></label>  
            <span id="roles"></span>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <input type="button" value="Limpiar Campos" onclick="limpiarCampos()()">&nbsp;&nbsp; 
            <br><br> 
            <label for="cedula">Cédula:&nbsp;&nbsp;</label>
            <input type="text" value=""  id="txtCedula">
            <br><br> 
            <label for="nombre">Nombre:&nbsp;&nbsp;</label>
            <input type="text" value=""  id="txtNombre">
            &nbsp;&nbsp; 
            <label for="primerApellido">Primer Apellido:&nbsp;&nbsp;</label>
            <input type="text" value=""  id="txtPrimerApellido">
            &nbsp;&nbsp;
            <label for="segundoApellido">Segundo Apellido:&nbsp;&nbsp;</label>
            <input type="text" value=""  id="txtSegundoApellido">
            <br><br> 
            <label for="fechaNacimiento">Fecha Nacimiento:&nbsp;&nbsp;</label>
            <input type="text" value=""  id="txtFechaNacimiento">
            <br><br>        
            <label for="direccionEmpleado">Dirección:</label><br>        
            <textarea rows="2" cols="40" maxlength="250s" value=""  id="txtDireccionEmpleado">
            </textarea> 
            <br><br>
            <label for="emailEmpleado">Email Empleado:&nbsp;&nbsp;</label>
            <input type="email" value=""  id="txtEmailEmpleado">
            &nbsp;&nbsp;
            <label for="login">Nombre Usuario:&nbsp;&nbsp;</label>
            <input type="text" value=""  id="txtLogin">
            &nbsp;&nbsp;
            <label for="password">Contraseña:&nbsp;&nbsp;</label>
            <input type="password" value=""  id="txtPassword">
            <br><br> 
            <label for="CantidadHorasLaborales">Cantidad de horas laborales:&nbsp;&nbsp;</label>
            <input type="number" value=""  id="txtCantidadHorasLaborales">
            &nbsp;&nbsp;
            <label for="CostoHoraExtra">Costo hora extra:&nbsp;&nbsp;</label>
            <input type="number" value=""  id="txtCostoHoraExtra">
            &nbsp;&nbsp;
            <label for="TiempoAlmuerzo">Tiempo almuerzo:&nbsp;&nbsp;</label>
            <input type="number" value=""  id="txtTiempoAlmuerzo">
            <br><br> 
            <input type="button" value="Insertar Empleado" onclick="insertarEmpleado();">&nbsp;&nbsp; 
            <input type="button" value="Modificar Empleado" onclick="actualizarEmpleado()">&nbsp;&nbsp; 
            <input type="button" value="Eliminar Empleado" onclick="eliminarEmpleado()">&nbsp;&nbsp;    
            <span id="resultado"></span><br>         
            <br>
            <div id="listaTelefonos" >

            </div>
        </form>
    </body>
</html>