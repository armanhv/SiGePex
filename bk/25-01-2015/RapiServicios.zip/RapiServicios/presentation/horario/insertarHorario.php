<?php
include '../../business/horarioBusiness.php';

//los valores almacenados que se enviarion por el cliente
$idHorario = $_POST['idHorario'];
$idEmpleado = $_POST['idEmpleado'];
$dias = $_POST['dias'];
$horaInicio = $_POST['horaInicio'];
$horaSalida = $_POST['horaSalida'];

//comunucacion con Business
$horarioBusiness = new horarioBusiness();

//se crea una instancia de horario
$newHorario = new horario(0, $idEmpleado, $dias, $horaInicio, $horaSalida);

//se inserta el horario
$resultado = $horarioBusiness->insertHorario($newHorario);

if ($resultado){
    echo 'Se inserto correctamente.';
}  else {
    echo 'Error al insertar.';
}