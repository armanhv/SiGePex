<?php

include "../../data/EmpleadoData.php";

class EmpleadoBusiness {

    //variables regarding composition
    private $empleadoData;

    public function EmpleadoBusiness() {
        $this->empleadoData = new EmpleadoData();
    }

    public function insertarEmpleado($empleado) {
        $resultado = $this->empleadoData->insertarEmpleado($empleado);
        return $resultado;
    }

    public function actualizarEmpleado($empleado) {
        $resultado = $this->empleadoData->actualizarEmpleado($empleado);
        return $resultado;
    }

    public function eliminarEmpleado($cedula) {
        $resultado = $this->empleadoData->eliminarEmpleado($cedula);
        return $resultado;
    }

    public function buscarEmpleado($idEmpleado) {
        $resultado = $this->empleadoData->buscarEmpleado($idEmpleado);
        return $resultado;
    }

    public function obtenerEmpleados() {
        $resultado = $this->empleadoData->obtenerEmpleados();
        return $resultado;
    }

}
