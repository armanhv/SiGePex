/******************* Metodos CRUD para SALARIO ***************************/
function insertarSalario() {

    var idSalario = 0;
    var idEmpleado = document.getElementById("cbxEmpleado").value;
    var salarioBase = document.getElementById("txtSalarioBase");
    var horasExtra = document.getElementById("txtHorasExtras");
    var bonificacines = document.getElementById("txtBonificaciones");
    var diasExtra = document.getElementById("txtDiasExtra");


    var parametros = {
        "idSalario": idSalario.value,
        "idEmpleado": idEmpleado,
        "salarioBase": salarioBase.value,
        "horasExtra": horasExtra.value,
        "bonificaciones": bonificacines.value,
        "diasExtra": diasExtra.value
    };

    $.ajax({
        data: parametros,
        url: 'insertarSalario.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $("#txtSalarioBase").val("");
            $("#txtHorasExtras").val("");
            $("#txtBonificaciones").val("");
            $("#txtDiasExtra").val("");
            obtenerSalarios();
            $("#resultado").html(response);
        }
    });

}

function borrarSalario() {
    var idSalario = document.getElementById("cbxSalarios").value;

    var parametros = {
        "idSalario": idSalario
    };

    $.ajax({
        data: parametros,
        url: 'borrarSalario.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $("#txtSalarioBase").val("");
            $("#txtHorasExtras").val("");
            $("#txtBonificaciones").val("");
            $("#txtDiasExtra").val("");
            obtenerSalarios();
            $("#resultado").html(response);
        }
    });
}

function actualizarSalario() {
    var idSalario = document.getElementById("cbxSalarios").value;
    var idEmpleado = document.getElementById("cbxEmpleado").value;
    var salarioBase = document.getElementById("txtSalarioBase");
    var horasExtra = document.getElementById("txtHorasExtras");
    var bonificacines = document.getElementById("txtBonificaciones");
    var diasExtra = document.getElementById("txtDiasExtra");

    var parametros = {
        "idSalario": idSalario,
        "idEmpleado": idEmpleado,
        "salarioBase": salarioBase.value,
        "horasExtra": horasExtra.value,
        "bonificaciones": bonificacines.value,
        "diasExtra": diasExtra.value
    };

    $.ajax({
        data: parametros,
        url: 'actualizarSalario.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $("#txtSalarioBase").val("");
            $("#txtHorasExtras").val("");
            $("#txtBonificaciones").val("");
            $("#txtDiasExtra").val("");
            obtenerSalarios();
            $("#resultado").html(response);
        }
    });
}

function obtenerSalarios() {
    $.ajax({
        data: '',
        url: 'obtenerSalarios.php',
        type: 'post',
        success: function (response) {
            $("#salarios").html(response);
        }


    });
}

function obtenerEmpleados() {
    $.ajax({
        data: '',
        url: 'obtenerEmpleadosSalario.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}

function cargarSalarios() {
    //Obtener los valores
    var idSalario = document.getElementById("cbxSalarios").value;

    var parametros = {
        "idSalario": idSalario
    };

    $.ajax({
        data: parametros,
        url: 'cargarCampos.php',
        type: 'post',
        success: function (response) {
            $("#tablaSalario").html(response);
        }
    });
}