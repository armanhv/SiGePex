/******************* Metodos CRUD para Pago de periodo ***************************/
function insertarPago() {

    var idPago = 0;
    var idEmpleado = document.getElementById("cbxEmpleado").value;
    var fechaInicio = document.getElementById("txtFechaInicio");
    var fechaFinal = document.getElementById("txtFechaFinal");
    var salarioBasePeriodo = document.getElementById("txtSalarioBasePeriodo");
    var horasExtra = document.getElementById("txtHorasExtrasPeriodo");
    var rebajos = document.getElementById("txtRebajos");

    var parametros = {
        "idPago": idPago.value,
        "idEmpleado": idEmpleado,
        "fechaInicio": fechaInicio.value,
        "fechaFinal": fechaFinal.value,
        "salarioBasePeriodo": salarioBasePeriodo.value,
        "horasExtra": horasExtra.value,
        "rebajos": rebajos.value
    };

    $.ajax({
        data: parametros,
        url: 'insertarPago.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $("#txtFechaInicio").val("");
            $("#txtFechaFinal").val("");
            $("#txtSalarioBasePeriodo").val("");
            $("#txtHorasExtrasPeriodo").val("");
            $("#txtRebajos").val("");
            obtenerEmpleadosPago();
            $("#resultado").html(response);
        }
    });

}

function borrarPago() {
    var idPago = document.getElementById("cbxPagos").value;

    var parametros = {
        "idPago": idPago
    };
    
    alert(idPago);

    $.ajax({
        data: parametros,
        url: 'borrarPago.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $("#txtFechaInicio").val("");
            $("#txtFechaFinal").val("");
            $("#txtSalarioBasePeriodo").val("");
            $("#txtHorasExtrasPeriodo").val("");
            $("#txtRebajos").val("");
            obtenerEmpleadosPago();
            $("#resultado").html(response);
        }
    });
}

function actualizarPago() {
    var idPago = document.getElementById("cbxPagos").value;
    var idEmpleado = document.getElementById("cbxEmpleado").value;
    var fechaInicio = document.getElementById("txtFechaInicio");
    var fechaFinal = document.getElementById("txtFechaFinal");
    var salarioBasePeriodo = document.getElementById("txtSalarioBasePeriodo");
    var horasExtra = document.getElementById("txtHorasExtrasPeriodo");
    var rebajos = document.getElementById("txtRebajos");
    
    var parametros = {
        "idPago": idPago,
        "idEmpleado": idEmpleado,
        "fechaInicio": fechaInicio.value,
        "fechaFinal": fechaFinal.value,
        "salarioBasePeriodo": salarioBasePeriodo.value,
        "horasExtra": horasExtra.value,
        "rebajos": rebajos.value
    };

    $.ajax({
        data: parametros,
        url: 'actualizarPago.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $("#txtFechaInicio").val("");
            $("#txtFechaFinal").val("");
            $("#txtSalarioBasePeriodo").val("");
            $("#txtHorasExtrasPeriodo").val("");
            $("#txtRebajos").val("");
            obtenerEmpleadosPago();
            $("#resultado").html(response);
        }
    });
}

function obtenerPagos() {
    $.ajax({
        data: '',
        url: 'obtenerPagos.php',
        type: 'post',
        success: function (response) {
            $("#listaPagos").html(response);
        }
    });
}

function obtenerEmpleadosPago() {
    $.ajax({
        data: '',
        url: 'obtenerEmpleadosPago.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}

function cargarPagos() {
    //Obtener los valores
    var idPago = document.getElementById("cbxPagos").value;

    var parametros = {
        "idPago": idPago
    };

    $.ajax({
        data: parametros,
        url: 'cargarCamposPago.php',
        type: 'post',
        success: function (response) {
            $("#tablaPago").html(response);
        }
    });
}