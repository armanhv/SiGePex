<?php

include '../../business/rolBusiness.php';


/* * *** CODIGO PARA LA DIFERENCIA DE HORAS **** */
include '../../domain/difHoras.php';
$dif = new difHoras();
echo '<br><br>_______________________<br><br>';

$hora_inicial = "9:00";
$hora_final = "16:00";
$diferencia = $dif->resta($hora_inicial, $hora_final);
$valor = $dif->format($diferencia);
$total = $dif->totalHoras();

echo 'La diferencia es de: ' . $valor;

echo '<br><br>_______________________<br><br>';

/* * ******************************************* */

//comunicacion con Business
$rolBusiness = new rolBusiness();
$listaRoles = $rolBusiness->getRoles();

echo '<SELECT onChange="cargarRoles()" NAME="cbxRoles" id="cbxRoles" SIZE=1>';

foreach ($listaRoles as $currentRol) {

    $idRol = $currentRol->idRol;
    $nombreRol = $currentRol->nombreRol;

    echo '<option value=' . $idRol . '>' . $nombreRol . '</option>';
}