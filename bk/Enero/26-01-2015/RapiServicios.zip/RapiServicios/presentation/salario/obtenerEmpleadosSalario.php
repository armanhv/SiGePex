<?php

include '../../business/EmpleadoBusiness.php';

//comunicacion con Business
$salarioBusines = new EmpleadoBusiness();
$listaEmpleados = $salarioBusines->obtenerEmpleados();

echo '<SELECT name="cbxEmpleado" id="cbxEmpleado" size=1>';
echo '<option value=0>Eliga un Empleado</option>';

foreach ($listaEmpleados as $currentEmpleado) {

    $idEmpleado = $currentEmpleado->idEmpleado;
    $nombreEmpleado = $currentEmpleado->nombreEmpleado . " " . $currentEmpleado->primerApellidoEmpleado . " " . $currentEmpleado->segundoApellidoEmpleado;
    
    echo '<option value=' . $idEmpleado . '>' . $nombreEmpleado . '</option>';
}



