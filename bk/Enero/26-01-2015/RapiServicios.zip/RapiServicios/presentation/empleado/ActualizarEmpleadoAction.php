<?php

include '../../business/EmpleadoBusiness.php';

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellido'];
$salario = $_POST['salario'];
$fechaEntrada = $_POST['fechaEntrada'];
$direccion = $_POST['direccion'];
$login = $_POST['login'];
$pass = $_POST['pass'];
$idHorario = $_POST['idHorario'];
$idRol = $_POST['idRol'];
$empleadoBusiness=new EmpleadoBusiness();
$horario = new horario($idHorario,"","","");
$rol = new rol($idRol,"");

$empleado = new Empleado($cedula,$nombre,$apellidos,$salario,$fechaEntrada,$direccion,$login,$pass,$horario,$rol);
$result = $empleadoBusiness->actualizarEmpleado($empleado);
        
if($result){
      echo 'Se actualizo correactamente!';
}else{
      echo 'No se actualizo!';
}
    