<?php

include '../../business/EmpleadoBusiness.php';

//comunicacion con Business
$licenciaBusiness = new EmpleadoBusiness();
$listaEmpleados = $licenciaBusiness->obtenerEmpleados();

echo '<SELECT onChange="cargarEmpleados()" NAME="cbxEmpleado" id="cbxEmpleado" SIZE=1>';

foreach ($listaEmpleados as $currentEmpleado) {

    $idEmpleado = $currentEmpleado->cedulaEmpleado;
    $nombreEmpleado = $currentEmpleado->nombreEmpleado;
    $apellidos = $currentEmpleado->primerApellidoEmpleado;
    echo '<option value=' . $idEmpleado . '>' . $idEmpleado .' - '. $nombreEmpleado . ' - ' . $apellidos . '</option>';
}



