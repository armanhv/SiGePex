<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>RapiServicios</title>     
        <script type="text/javascript" src="../../js/ajaxHorario.js"></script>    
        <script type="text/javascript" src="../../js/jquery.js"></script>    
    </head>

    <body style="" onload="obtenerEmpleadosHorario()">
        <div style="margin-left: 340px">
            <p>Módulo Horario</p>

            <label for="Empleado">Eliga un Empleado:</label>
            <span id="empleados"></span><br>

            <table>
                <tr>
                    <td><label for="Dias">Días de Trabajo:&nbsp;&nbsp;</label></td>
                    <td>
                        <select name="cbxDias" id="cbxDias" >
                            <option value="Lunes">Lunes</option>
                            <option value="Martes">Martes</option>
                            <option value="Miércoles">Miércoles</option>
                            <option value="Jueves">Jueves</option>
                            <option value="Viernes">Viernes</option>
                            <option value="Sábado">Sábado</option>
                            <option value="Domingo">Domingo</option>
                        </select>
                    </td>
                    <td><label for="HoraInicio">Hora Inicio:</label></td>
                    <td>
                        <select name="cbxHoraInicio" id="cbxHoraInicio" >
                            <option value="01:00">01:00</option>
                            <option value="02:00">02:00</option>
                            <option value="03:00">03:00</option>
                            <option value="04:00">04:00</option>
                            <option value="05:00">05:00</option>
                            <option value="06:00">06:00</option>
                            <option value="07:00">07:00</option>
                            <option value="08:00">08:00</option>
                            <option value="09:00">09:00</option>
                            <option value="10:00">10:00</option>
                            <option value="11:00">11:00</option>
                            <option value="12:00">12:00</option>
                        </select>
                    </td>
                    <td>
                        <input type="radio" id="radioHoraIni" name="radioHoraIni" value="am" checked>am<br>
                        <input type="radio" id="radioHoraIni" name="radioHoraIni" value="pm">pm
                    </td>
                    <td><label for="HoraSalida">Hora de salida:</label></td>
                    <td>
                        <select name="cbxHoraInicio" id="cbxHoraInicio" >
                            <option value="01:00">01:00</option>
                            <option value="02:00">02:00</option>
                            <option value="03:00">03:00</option>
                            <option value="04:00">04:00</option>
                            <option value="05:00">05:00</option>
                            <option value="06:00">06:00</option>
                            <option value="07:00">07:00</option>
                            <option value="08:00">08:00</option>
                            <option value="09:00">09:00</option>
                            <option value="10:00">10:00</option>
                            <option value="11:00">11:00</option>
                            <option value="12:00">12:00</option>
                        </select>
                    </td>
                    <td>
                        <input type="radio" id="radioHoraSali" name="radioHoraSali" value="am">am<br>
                        <input type="radio" id="radioHoraSali" name="radioHoraSali" value="pm" checked>pm
                    </td>
                </tr>
                <tr>
                    <td><input type="button" value="Insertar" onclick="insertarHorario()">&nbsp;&nbsp;</td>
                </tr>
            </table><br>

            <span id="resultado"></span><br>

            <div id="listaHorarios" >

            </div>

        </div>
    </body>
</html>
