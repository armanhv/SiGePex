<?php

include 'BaseDatos.php';
include '../../domain/salario.php';
include '../../domain/empleado.php';

class salarioData {

    private $conexion;

    public function salarioData() {
        $this->conexion = new BaseDatos();
    }

    public function insertarSalario($salario) {

        $resultadoId = mysqli_query($this->conexion->abrirConexion(), "SELECT idSalario FROM tbSalario ORDER BY idSalario DESC LIMIT 1;");
        while ($fila = mysqli_fetch_array($resultadoId)) {
            $idNuevo = $fila['idSalario'];
        }
        $idNuevo = $idNuevo + 1;

        $query = "insert into tbSalario values (" . $idNuevo. ", " . $salario->idEmpleado . ", "
                . $salario->salarioBase . ", " . $salario->horasExtraSalario . ", " . $salario->bonificacionesSalario . ", "
                . $salario->diasExtraSalario . ");";

        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function actualizarSalario($salario) {

        $query = "update tbSalario set identificacionEmpleado=" . $salario->idEmpleado . ", salarioBase=" . $salario->salarioBase
                . ", horasExtraSalario=" . $salario->horasExtraSalario . ", bonificacionesSalario=" . $salario->bonificacionesSalario
                . ", diasExtraSalario=" . $salario->diasExtraSalario . " where idSalario=" . $salario->idSalario . ";";

        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function eliminarSalario($idSalario) {
        $query = "delete from tbSalario where idSalario=" . $idSalario . ";";

        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function obtenerSalarios() {
        $query = "select* from tbSalario";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $arraySalarios = [];

        while ($row = mysqli_fetch_array($result)) {
            $salarioActual = new salario($row['idSalario'], $row['identificacionEmpleado'], $row['salarioBase'], $row['horasExtraSalario'], $row['bonificacionesSalario'], $row['diasExtraSalario']);
            array_push($arraySalarios, $salarioActual);
        }

        $this->conexion->cerrarConexion();

        return $arraySalarios;
    }

    public function buscarSalario($idSalario) {
        $query = "SELECT * FROM tbSalario WHERE(idSalario =" . $idSalario . ")";
        $resulGeneral = mysqli_query($this->conexion->abrirConexion(), $query);

        $row = $resulGeneral->fetch_array();

        $salario = new salario($row['idSalario'], $row['identificacionEmpleado'], $row['salarioBase'], $row['horasExtraSalario'], $row['bonificacionesSalario'], $row['diasExtraSalario']);

        $this->conexion->cerrarConexion();
        return $salario;
    }

    public function buscarEmpleadoSalario($identificacionEmpleado) {
        $query = "SELECT * FROM tbempleado WHERE(identificacionEmpleado =" . $identificacionEmpleado . ")";
        $resulGeneral = mysqli_query($this->conexion->abrirConexion(), $query);

        $row = $resulGeneral->fetch_array();

        $empleado = new empleado($row['identificacionEmpleado'], $row['cedulaEmpleado'], $row['nombreEmpleado'], $row['primerApellidoEmpleado'], $row['segundoApellidoEmpleado'], $row['fechaNacimiento'], $row['emailEmpleado'], $row['direccionEmpleado'], $row['loginEmpleado'], $row['passwordEmpleado'], $row['idRolEmpleado']);

        $this->conexion->cerrarConexion();
        return $empleado;
    }

}
