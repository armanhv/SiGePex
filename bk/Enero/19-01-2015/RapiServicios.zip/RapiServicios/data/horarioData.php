<?php

include 'BaseDatos.php';
include '../../domain/empleado.php';
include '../../domain/horario.php';

class horarioData {

    //Variables 
    private $conexion;

    //constructor
    public function horarioData() {
        $this->conexion = new BaseDatos();
    }

    //Metodo para insertar un horario
    public function insertHorario($horario) {

        $resultadoId = mysqli_query($this->conexion->abrirConexion(), "SELECT idHorario FROM tbhorario ORDER BY idHorario DESC LIMIT 1;");
        while ($fila = mysqli_fetch_array($resultadoId)) {
            $idNuevo = $fila['idHorario'];
        }
        $idNuevo = $idNuevo + 1;

        $query = "insert into tbhorario values(" . $idNuevo . ", "
                . $horario->idEmpleadoHorario . ", '" . $horario->diaHorario . "', '"
                . $horario->horaInicio . "', '" . $horario->horaSalida . "');";

        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    //Metodo para eliminara un horario
    public function deleteHorario($idHorario) {
        $query = "delete from tbhorario where idHorario=" . $idHorario . ";";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    //Metodo para actualizar un horario
    public function updateHorario($horario) {
        $query = "update tbhorario set idEmpleadoHorario=" . $horario->idEmpleadoHorario
                . ", dias='" . $horario->diaHorario . "', horaInicio='" . $horario->horaInicio
                . "', horaSalida='" . $horario->horaSalida . "' where idHorario =" . $horario->idHorario;

        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    //Metodo para obtener todos los horarios
    public function getHorarios() {

        $query = "select* from tbhorario";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $arrayHorarios = [];

        while ($row = mysqli_fetch_array($result)) {
            $horarioActual = new horario($row['idHorario'], $row['idEmpleadoHorario'], $row['diaHorario'], $row['horaInicio'], $row['horaSalida']);

            array_push($arrayHorarios, $horarioActual);
        }

        $this->conexion->cerrarConexion();

        return $arrayHorarios;
    }

    //metodo par abuscar un solo horario por id
    public function buscarHorario($idHorario) {
        $query = "SELECT * FROM tbhorario WHERE(idHorario =" . $idHorario . ")";
        $resulGeneral = mysqli_query($this->conexion->abrirConexion(), $query);

        $row = $resulGeneral->fetch_array();

        $salario = new horario($row['idHorario'], $row['idEmpleadoHorario'], $row['diaHorario'], $row['horaInicio'], $row['horaSalida']);

        $this->conexion->cerrarConexion();

        return $salario;
    }

    //metodo para traer los empleados
    public function buscarEmpleadoHorario($identificacionEmpleado) {
        $query = "SELECT * FROM tbempleado WHERE(identificacionEmpleado =" . $identificacionEmpleado . ")";
        $resulGeneral = mysqli_query($this->conexion->abrirConexion(), $query);

        $row = $resulGeneral->fetch_array();

        $empleado = new empleado($row['identificacionEmpleado'], $row['cedulaEmpleado'], $row['nombreEmpleado'], $row['primerApellidoEmpleado'], $row['segundoApellidoEmpleado'], $row['fechaNacimiento'], $row['emailEmpleado'], $row['direccionEmpleado'], $row['loginEmpleado'], $row['passwordEmpleado'], $row['idRolEmpleado']);

        $this->conexion->cerrarConexion();
        return $empleado;
    }

    //Metodo para obtener todos los horarios
    public function buscarHorarioDeEmpleado($idEmpleado) {
        $query = "SELECT * FROM tbhorario WHERE (idEmpleadoHorario =" . $idEmpleado . ")";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $arrayHorarios = [];

        while ($row = mysqli_fetch_array($result)) {
            $horarioActual = new horario($row['idHorario'], $row['idEmpleadoHorario'], $row['diaHorario'], $row['horaInicio'], $row['horaSalida']);

            array_push($arrayHorarios, $horarioActual);
        }

        $this->conexion->cerrarConexion();

        return $arrayHorarios;
    }

    //Metodo para insertar un horario
    public function obtenerUltimoID($idTabla, $tabla) {

        $query = "SELECT " . $idTabla . " FROM " . $tabla . " ORDER BY " . $idTabla . " DESC LIMIT 1;";

        $result = mysqli_query($this->conexion->abrirConexion(), $query);

        $id = mysqli_fetch_array($result);

        $this->conexion->cerrarConexion();

        return $id;
    }

}
