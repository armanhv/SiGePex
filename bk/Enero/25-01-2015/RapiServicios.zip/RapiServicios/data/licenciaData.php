<?php
include_once 'BaseDatos.php';
include_once 'domain/licencia.php';

class licenciaData {

    private $conexion;

    public function licenciaData() {
        $this->conexion = new BaseDatos();
    }

    public function insertarLicencia($identificacionEmpleado, $objLicenciaEmleado) { 
        
        echo ''.$objLicenciaEmleado->fechaEmisionLicencia . "', '" . $objLicenciaEmleado->fechaExpiracionLicencia ;
        $query = "insert into tbLicencia values (" . $identificacionEmpleado . ", '" . $objLicenciaEmleado->tipoLicencia . "', '"
                . $objLicenciaEmleado->fechaEmisionLicencia . "', '" . $objLicenciaEmleado->fechaExpiracionLicencia . "');";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $this->conexion->cerrarConexion();
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function actualizarLicencia($identificacionEmpleado, $objLicenciaEmleado) {
       $query = "update tbLicencia set fechaEmisionLicencia = '" . $objLicenciaEmleado->fechaEmisionLicencia . "', fechaExpiracionLicencia= '" . $objLicenciaEmleado->fechaExpiracionLicencia . 
                "' where identificacionEmpleadoLicencia='" . $identificacionEmpleado. "' and tipoLicencia='".$objLicenciaEmleado->tipoLicencia."' ;";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $this->conexion->cerrarConexion();

        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function eliminarLicencia($identificacionEmpleado, $tipoLicencia) {
        $query = "delete from tbLicencia where identificacionEmpleadoLicencia='" . $identificacionEmpleado. "' and tipoLicencia='".$tipoLicencia."' ;";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $this->conexion->cerrarConexion();
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function buscarLicencia($identificacionEmpleado, $objLicenciaEmleado) {
        $query = "select * from tbLicencia identificacionEmpleadoLicencia='" . $identificacionEmpleado. "' and tipoLicencia='".$objLicenciaEmleado->tipoLicencia."' ;";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $arrayLicencias = [];

        while ($row = mysqli_fetch_array($result)) {
            $licenciaEmpleado= new licencia($row['tipoLicencia'], $row['fechaEmisonLicencia'], $row['fechaExpiracionLicencia']);
            array_push($arrayLicencias, $licenciaEmpleado);
        }
        $this->conexion->cerrarConexion();
        return $arrayLicencias;
    }
    
    
    public function buscarLicenciasEmpleado($identificacionEmpleado) {
        $query = "select * from tbLicencia identificacionEmpleadoLicencia='" . $identificacionEmpleado."' ;";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $arrayLicencias = [];

        while ($row = mysqli_fetch_array($result)) {
            $licenciaEmpleado= new licencia($row['tipoLicencia'], $row['fechaEmisonLicencia'], $row['fechaExpiracionLicencia']);
            array_push($arrayLicencias, $licenciaEmpleado);
        }
        $this->conexion->cerrarConexion();
        return $arrayLicencias;
    }

    public function obtenerLicencias() {
        $query = "select identificacionEmpleado from tbEmpleado;";
        $result = mysqli_query($this->conexion->abrirConexion(), $query);
        $arrayLicencias = [];
        while ($row = mysqli_fetch_array($result)) {
           
            $licenciaEmpleado= new licencia($row['tipoLicencia'], $row['fechaEmisonLicencia'], $row['fechaExpiracionLicencia']);
            array_push($arrayLicencias, buscarLicenciasEmpleado($identificacionEmpleado));
        }
        $this->conexion->cerrarConexion();
        return $arrayLicencias;
    }

}
