<?php

class horario {

    //Atributos del objeto
    public $idHorario;
    public $idEmpleadoHorario;
    public $diaHorario;
    public $horaInicio;
    public $horaSalida;

    //Metodo constructor 
    public function horario($idHorario, $idEmpleadoHorario, $diaHorario, $horaInicio, $horaSalida) {
        $this->idHorario = $idHorario;
        $this->idEmpleadoHorario = $idEmpleadoHorario;
        $this->diaHorario = $diaHorario;
        $this->horaInicio = $horaInicio;
        $this->horaSalida = $horaSalida;
    }// fin metodo constructor

}
