<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>RapiServicios</title>     
        <script type="text/javascript" src="../../js/ajaxPagoPeriodo.js"></script>    
        <script type="text/javascript" src="../../js/jquery.js"></script>    
    </head>

    <body style="" onload="obtenerEmpleadosPago();obtenerPagos()">
        <div style="margin-left: 340px">
            <p>Módulo Pago por Periodos</p>

            <div id="tablaPago">
                <table>
                    <tr>
                        <td><label for="Empleado">Eliga un Empleado:</label></td>
                        <td><span id="empleados"></span></td>
                    </tr>
                    <tr>
                        <td><label for="fechaInicio">Fecha de Inicio:</label></td>
                        <td><input type="date" id="txtFechaInicio" name="txtFechaInicio"></td>
                    </tr>
                    <tr>
                        <td><label for="fechaFinal">Fecha Final:</label></td>
                        <td><input type="date" id="txtFechaFinal" name="txtFechaFinal"></td>
                    </tr>
                    <tr>
                        <td><label for="salarioBasePeriodo">Salario Base del Periodo:</label></td>
                        <td><input type="text" id="txtSalarioBasePeriodo" name="txtSalarioBasePeriodo"></td>
                    </tr>
                    <tr>
                        <td><label for="montoHorasExtra">Monto por Horas Extra:</label></td>
                        <td><input type="text" id="txtHorasExtrasPeriodo" name="txtHorasExtrasPeriodo"></td>
                    </tr>
                    <tr>
                        <td><label for="rebajos">Rebajos:</label></td>
                        <td><input type="text" id="txtRebajos" name="txtRebajos"></td>
                    </tr>
                    <tr>
                        <td><input type="button" value="Insertar" onclick="insertarPago()">&nbsp;&nbsp;</td>
                        <td><input type="button" value="Modificar" onclick="actualizarPago()">&nbsp;&nbsp;</td>
                        <td><input type="button" value="Eliminar" onclick="borrarPago()">&nbsp;&nbsp;</td>
                    </tr>
                </table>

            </div>
            <br>
            <span id="resultado"></span><br>

            <div id="listaPagos" >

            </div>

        </div>
    </body>
</html>
