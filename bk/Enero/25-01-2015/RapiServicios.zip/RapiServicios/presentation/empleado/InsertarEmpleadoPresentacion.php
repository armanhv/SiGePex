<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>     
        <script type="text/javascript" src="../../js/ajax.js"></script>    
        <script type="text/javascript" src="../../js/jquery.js"></script>   
    </head>
    <body style="" onload="obtenerHorarios();obtenerRoles();obtenerEmpleados()">
        <p><font size=6>Mantenimiento de  Empleados </font></p>
        <br>        
        <label for="empleados"><font size=5>Empleados:&nbsp;&nbsp;</font></label>  
        <span id="empleados"></span><br><br>
        
        <label for="cedula">Cédula:&nbsp;&nbsp;</label>
        <input type="text" value=""  id="txtCedula">
        <br><br> 
        <label for="nombre">Nombre:&nbsp;&nbsp;</label>
        <input type="text" value=""  id="txtNombre">
        <br><br> 
        <label for="apellido">Apellidos:&nbsp;&nbsp;</label>
        <input type="text" value=""  id="txtApellido">
        <br><br> 
        <label for="salario">Salario:&nbsp;&nbsp;</label>
        <input type="number" value=""  id="txtSalario">
        <br><br>
        <label for="fechaEntrada">Fecha de Entrada:&nbsp;&nbsp;</label>
        <input type="date" value=""  id="txtFechaEntrada">
        <br><br>
        <label for="direccion">Dirección:&nbsp;&nbsp;</label>
        <input type="text" value=""  id="txtDireccion">
        <br><br>
        <label for="login">Nombre Usuario:&nbsp;&nbsp;</label>
        <input type="text" value=""  id="txtLogin">
        <br><br>
        <label for="password">Contraseña:&nbsp;&nbsp;</label>
        <input type="password" value=""  id="txtPassword">
        <br><br>
        <label for="horario">Horario:&nbsp;&nbsp;</label>
        <span id="horarios"></span>
        <br><br>
        <label for="rol">Rol:&nbsp;&nbsp;</label>
        <span id="roles"></span>
        <br><br>      

        <input type="button" value="Insertar Empleado" onclick="insertarEmpleado()">&nbsp;&nbsp; 
        <input type="button" value="Actualizar Empleado" onclick="actualizarEmpleado()">&nbsp;&nbsp; 
        <input type="button" value="Eliminar Empleado" onclick="eliminarEmpleado()">&nbsp;&nbsp;    
        <span id="resultado"></span><br><br>
        
    </body>
</html>