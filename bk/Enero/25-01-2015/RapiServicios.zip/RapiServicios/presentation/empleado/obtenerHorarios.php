<?php

include '../../business/horarioBusiness.php';

//comunicacion con Business
$horarioBusiness = new horarioBusiness();
$listaHorarios = $horarioBusiness->getHorarios();

echo '<SELECT onChange="cargarHorarios()" NAME="cbxHorarios" id="cbxHorarios" SIZE=1>';

foreach ($listaHorarios as $currentHorario) {

    $idHorario = $currentHorario->idHorario;
    $dias = $currentHorario->diaHorario;
    $horaInicio = $currentHorario->horaInicio;
    $horaSalida = $currentHorario->horaSalida;

    echo '<option value=' . $idHorario . '>' . $dias . ' - ' . $horaInicio . ' - ' . $horaSalida . '</option>';
}