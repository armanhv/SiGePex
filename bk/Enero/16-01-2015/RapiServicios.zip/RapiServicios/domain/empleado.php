<?php

class empleado {

    //variables
    public $identificacionEmpleado;
    public $cedulaEmpleado;
    public $nombreEmpleado;
    public $primerApellidoEmpleado;
    public $segundoApellidoEmpleado;
    public $fechaNacimientoEmpleado;
    public $emailEmpleado;
    public $direccionEmpleado;
    public $loginEmpleado;
    public $passwordEmpleado;
    public $objRol;
    public $objListaLicencias;    
    public $objHorario;

//Constructor method
    public function empleado($identificacionEmpleado,$cedulaEmpleado, $nombreEmpleado, $primerApellidoEmpleado,$segundoApellidoEmpleado,$fechaNacimientoEmpleado,
            $emailEmpleado,$direccionEmpleado,$loginEmpleado,$passwordEmpleado,$objRol) {
        $this->identificacionEmpleado = $identificacionEmpleado;
        $this->cedulaEmpleado = $cedulaEmpleado;
        $this->nombreEmpleado = $nombreEmpleado;
        $this->primerApellidoEmpleado = $primerApellidoEmpleado;
        $this->segundoApellidoEmpleado = $segundoApellidoEmpleado;
        $this->fechaNacimientoEmpleado = $fechaNacimientoEmpleado;
        $this->emailEmpleado = $emailEmpleado;
        $this->direccionEmpleado = $direccionEmpleado;
        $this->loginEmpleado = $loginEmpleado;
        $this->passwordEmpleado = $passwordEmpleado;
        $this->objRol = $objRol;
        
    }//End constructor method

//    //Constructor method
//    public function empleado($identificacionEmpleado,$cedulaEmpleado, $nombreEmpleado, $primerApellidoEmpleado,$segundoApellidoEmpleado,$fechaNacimientoEmpleado,
//            $emailEmpleado,$direccionEmpleado,$loginEmpleado,$passwordEmpleado,$objRol,$objListaLicencias) {
//        $this->identificacionEmpleado = $identificacionEmpleado;
//        $this->cedulaEmpleado = $cedulaEmpleado;
//        $this->nombreEmpleado = $nombreEmpleado;
//        $this->primerApellidoEmpleado = $primerApellidoEmpleado;
//        $this->segundoApellidoEmpleado = $segundoApellidoEmpleado;
//        $this->fechaNacimientoEmpleado = $fechaNacimientoEmpleado;
//        $this->emailEmpleado = $emailEmpleado;
//        $this->direccionEmpleado = $direccionEmpleado;
//        $this->loginEmpleado = $loginEmpleado;
//        $this->passwordEmpleado = $passwordEmpleado;
//        $this->objRol = $objRol;
//        $this->objListaLicencias=$objListaLicencias;
//        
//    }//End constructor method

    //metodo para imprimir el objeto
    public function toString() {
        $resultado = $this->cedulaEmpleado . " " . $this->nombreEmpleado . " " ;
        return $resultado;
    }

}
