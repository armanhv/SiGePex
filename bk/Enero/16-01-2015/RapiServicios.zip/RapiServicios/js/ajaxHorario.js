/******************* Metodos CRUD para HORARIO ***************************/
function insertarHorario() {
    var idHorario = 0;
    var dias = document.getElementById("txtDias");
    var horaInicio = document.getElementById("txtHoraInicio");
    var horaSalida = document.getElementById("txtHoraSalida");

    var parametros = {
        "idHorario": idHorario.value,
        "dias": dias.value,
        "horaInicio": horaInicio.value,
        "horaSalida": horaSalida.value
    };

    $.ajax({
        data: parametros,
        url: 'insertarHorario.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpo los espacios
            $("#txtDias").val("");
            $("#txtHoraInicio").val("");
            $("#txtHoraSalida").val("");
            obtenerHorarios();
            $("#resultado").html(response);
        }
    });

}

function borrarHorario() {
    var idHorario = document.getElementById("cbxHorarios").value;

    var parametros = {
        "idHorario": idHorario
    };

    $.ajax({
        data: parametros,
        url: 'borrarHorario.php',
        type: 'post',
        success: function (response) {
            $("#txtDias").val("");
            $("#txtHoraInicio").val("");
            $("#txtHoraSalida").val("");
            obtenerHorarios();
            $("#resultado").html(response);
        }
    });
}

function actualizarHorario() {
    var idHorario = document.getElementById("cbxHorarios").value;
    var dias = document.getElementById("txtDias");
    var horaInicio = document.getElementById("txtHoraInicio");
    var horaSalida = document.getElementById("txtHoraSalida");

    var parametros = {
        "idHorario": idHorario,
        "dias": dias.value,
        "horaInicio": horaInicio.value,
        "horaSalida": horaSalida.value
    };

    $.ajax({
        data: parametros,
        url: 'actualizarHorario.php',
        type: 'post',
        success: function (response) {
            $("#txtDias").val("");
            $("#txtHoraInicio").val("");
            $("#txtHoraSalida").val("");
            obtenerHorarios();
            $("#resultado").html(response);
        }
    });
}

function obtenerHorarios() {
    $.ajax({
        data: '',
        url: 'obtenerHorarios.php',
        type: 'post',
        success: function (response) {
            $("#horarios").html(response);
        }
    });
}

function cargarHorarios() {
    //Obtener los valores
    var idHorario = document.getElementById("cbxHorarios").value;
    var combo = document.getElementById("cbxHorarios");
    var dias = combo.options[combo.selectedIndex].text;

    /* HACER UN SPLIT PARA SACER LOS VALORES */

    dias = dias.split("-");// Utilizamos el método split

    //Cargar los valores en el cuadro de texto
    var txtDias = document.getElementById("txtDias");
    txtDias.value = dias[0].trim();

    var txtHoraInicio = document.getElementById("txtHoraInicio");
    txtHoraInicio.value = dias[1].trim();

    var txtHoraSalida = document.getElementById("txtHoraSalida");
    txtHoraSalida.value = dias[2].trim();
}

function obtenerEmpleadosHorario() {
    $.ajax({
        data: '',
        url: 'obtenerEmpleadosHorario.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}


