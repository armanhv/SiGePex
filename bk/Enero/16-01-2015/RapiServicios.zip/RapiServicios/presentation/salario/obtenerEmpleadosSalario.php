<?php

include '../../business/EmpleadoBusiness.php';

//comunicacion con Business
$licenciaBusiness = new EmpleadoBusiness();
$listaEmpleados = $licenciaBusiness->obtenerEmpleados();

echo '<SELECT name="cbxEmpleado" id="cbxEmpleado" size=1>';
echo '<option value=0>Eliga un Empleado</option>';

foreach ($listaEmpleados as $currentEmpleado) {

    $idEmpleado = $currentEmpleado->identificacionEmpleado;
    $cedulaEmpleado = $currentEmpleado->cedulaEmpleado;
    $nombreEmpleado = $currentEmpleado->nombreEmpleado . " " . $currentEmpleado->primerApellidoEmpleado . " " . $currentEmpleado->segundoApellidoEmpleado;
    echo '<option value=' . $idEmpleado . '>' . $nombreEmpleado . '</option>';
}



