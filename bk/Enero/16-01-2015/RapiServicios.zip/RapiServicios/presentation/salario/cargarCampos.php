<?php

include '../../business/salarioBusiness.php';

//los valores almacenados que se enviarion por el cliente
$idSalario = $_POST['idSalario'];

$salarioBusines = new salarioBusiness(); //comunucacion con Business
$salario = $salarioBusines->buscarSalario($idSalario);

echo '
    <table>
        <tr>
            <td><label for="salarioBase">Salario Base:</label></td>
            <td><input type="text" name="txtSalarioBase" id="txtSalarioBase" value="' . $salario->salarioBase . '"></td>
        </tr>
        <tr>
            <td><label for="HorasExtra">Hora Extra:</label></td>
            <td><input type="text" name="txtHorasExtras" id="txtHorasExtras" value="' . $salario->horasExtraSalario . '"></td>
        </tr>
        <tr>
            <td><label for="bonificaciones">Bonificaciones:</label></td>
            <td> <input type="text" name="txtBonificaciones" id="txtBonificaciones" value="' . $salario->bonificacionesSalario . '"></td>
        </tr>
        <tr>
            <td><label for="diasExtra">Dias Extra:</label></td>
            <td> <input type="text" name="txtDiasExtra" id="txtDiasExtra" value="' . $salario->diasExtraSalario . '"></td>
        </tr>
        <tr>
            <td><input type="button" value="Insertar" onclick="insertarSalario()">&nbsp;&nbsp;</td>
            <td><input type="button" value="Actualizar" onclick="actualizarSalario()">&nbsp;&nbsp;</td>
            <td><input type="button" value="Borrar" onclick="borrarSalario()">&nbsp;&nbsp;</td>
        </tr>
    </table>
';
