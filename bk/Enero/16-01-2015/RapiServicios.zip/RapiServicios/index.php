
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <a href="presentation/rol/rolPresentacion.php">Rol</a>
        <br >
        <a href="presentation/horario/horarioPresentacion.php">Horario</a>
        <br>
        <a href="presentation/empleado/InsertarEmpleadoPresentacion.php">Empleado</a>
        <br>
        <a href="presentation/salario/salarioPresentacion.php">Salario</a>
    </body>
</html>
