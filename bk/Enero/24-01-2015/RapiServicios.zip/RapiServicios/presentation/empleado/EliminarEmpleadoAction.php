<?php
error_reporting(5);
include '../../business/EmpleadoBusiness.php';
$cedula = $_POST['cedula'];
$empleadoBusiness=new EmpleadoBusiness();
$result = $empleadoBusiness->eliminarEmpleado($cedula);
        
if($result){
      echo 'Se elimino correactamente';
}else{
      echo 'No se elimino correactamente';
}
    

