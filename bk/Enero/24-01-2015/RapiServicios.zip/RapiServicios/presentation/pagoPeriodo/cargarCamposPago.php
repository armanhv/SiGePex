<?php

include '../../business/pagoPeriodoBusiness.php';

//los valores almacenados que se enviarion por el cliente
$idPago = $_POST['idPago'];

$pagoBusines = new pagoPeriodoBusiness(); //comunucacion con Business
$pago = $pagoBusines->buscarPagoPeriodo($idPago);

echo '
    <table>
        <tr>
            <td><label for="fechaInicio">Fecha de Inicio:</label></td>
            <td><input type="date" id="txtFechaInicio" name="txtFechaInicio" value="' . $pago->fechaInicioPeriodo . '"></td>
        </tr>
        <tr>
            <td><label for="fechaFinal">Fecha Final:</label></td>
            <td><input type="date" id="txtFechaFinal" name="txtFechaFinal" value="' . $pago->fechaFinPeriodo . '"></td>
        </tr>
        <tr>
            <td><label for="salarioBasePeriodo">Salario Base del Periodo:</label></td>
            <td><input type="text" id="txtSalarioBasePeriodo" name="txtSalarioBasePeriodo" value="' . $pago->salarioBasePeriodo . '"></td>
        </tr>
        <tr>
            <td><label for="montoHorasExtra">Monto por Horas Extra:</label></td>
            <td><input type="text" id="txtHorasExtrasPeriodo" name="txtHorasExtrasPeriodo" value="' . $pago->montoHorasExtra . '"></td>
        </tr>
        <tr>
            <td><label for="rebajos">Rebajos:</label></td>
            <td><input type="text" id="txtRebajos" name="txtRebajos" value="' . $pago->rebajosPeriodo . '"></td>
        </tr>
        <tr>
            <td><input type="button" value="Insertar" onclick="insertarPago()">&nbsp;&nbsp;</td>
            <td><input type="button" value="Modificar" onclick="actualizarPago()">&nbsp;&nbsp;</td>
            <td><input type="button" value="Eliminar" onclick="borrarPago()">&nbsp;&nbsp;</td>
        </tr>
    </table>
';


