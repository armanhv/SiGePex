/******************* Metodos CRUD para ROL ***************************/
function insertarRol() {
    var idRol = 0;
    var nombreRol = document.getElementById("txtNombreRol");

    var parametros = {
        "idRol": idRol.value,
        "nombreRol": nombreRol.value
    };

    $.ajax({
        data: parametros,
        url: 'insertarRol.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpo los espacios
            $("#txtNombreRol").val("");
            obtenerRoles();
            $("#resultado").html(response);
        }
    });

}

function borrarRol() {
    var idRol = document.getElementById("cbxRoles").value;

    var parametros = {
        "idRol": idRol
    };

    $.ajax({
        data: parametros,
        url: 'borrarRol.php',
        type: 'post',
        success: function (response) {
            $("#txtNombreRol").val("");
            obtenerRoles();
            $("#resultado").html(response);
        }
    });
}

function actualizarRol() {
    var idRol = document.getElementById("cbxRoles").value;
    var nombreRol = document.getElementById("txtNombreRol");

    var parametros = {
        "idRol": idRol,
        "nombreRol": nombreRol.value
    };

    $.ajax({
        data: parametros,
        url: 'actualizarRol.php',
        type: 'post',
        success: function (response) {
            $("#txtNombreRol").val("");
            obtenerRoles();
            $("#resultado").html(response);
        }
    });
}

function obtenerRoles() {
    $.ajax({
        data: '',
        url: 'obtenerRoles.php',
        type: 'post',
        success: function (response) {
            $("#roles").html(response);
        }
    });
}

function cargarRoles() {
    //Obtener los valores
    var idRol = document.getElementById("cbxRoles").value;
    var combo = document.getElementById("cbxRoles");
    var nombreRol = combo.options[combo.selectedIndex].text;

    //Cargar los valores en el cuadro de texto
    var txtNombreRol = document.getElementById("txtNombreRol");
    txtNombreRol.value = nombreRol;
}

function eliminarEmpleado() {
    var valorCedula = document.getElementById("txtCedula");
    var parametros = {
        "cedula": valorCedula.value
    };

    $.ajax({
        data: parametros,
        url: 'EliminarEmpleadoAction.php',
        type: 'post',
        success: function (response) {
            $("#resultado").html(response);
        }
    });
    
    obtenerEmpleados();
}

function insertarEmpleado() {
    var valorCedula = document.getElementById("txtCedula");
    var valorNombre = document.getElementById("txtNombre");
    var valorApellido = document.getElementById("txtApellido");
    var valorSalario = document.getElementById("txtSalario");
    var valorFechaEntrada = document.getElementById("txtFechaEntrada");
    var valorDireccion = document.getElementById("txtDireccion");
    var valorLogin = document.getElementById("txtLogin");
    var valorPass = document.getElementById("txtPassword");
    var valorHorario = document.getElementById("cbxHorarios").value;
    var valorRol = document.getElementById("cbxRoles").value;

    var parametros = {
        "cedula": valorCedula.value,
        "nombre": valorNombre.value,
        "apellido": valorApellido.value,
        "salario": valorSalario.value,
        "fechaEntrada": valorFechaEntrada.value,
        "direccion": valorDireccion.value,
        "login": valorLogin.value,
        "pass": valorPass.value,
        "idHorario": valorHorario,
        "idRol": valorRol
    };
    $.ajax({
        data: parametros,
        url: 'InsertarEmpleadoAction.php',
        type: 'post',
        success: function (response) {
            $("#resultado").html(response);
        }
    });
    cargarEmpleados();
}

function actualizarEmpleado() {
    var valorCedula = document.getElementById("txtCedula");
    var valorNombre = document.getElementById("txtNombre");
    var valorApellido = document.getElementById("txtApellido");
    var valorSalario = document.getElementById("txtSalario");
    var valorFechaEntrada = document.getElementById("txtFechaEntrada");
    var valorDireccion = document.getElementById("txtDireccion");
    var valorLogin = document.getElementById("txtLogin");
    var valorPass = document.getElementById("txtPassword");
    var valorHorario = document.getElementById("cbxHorarios").value;
    var valorRol = document.getElementById("cbxRoles").value;

    var parametros = {
        "cedula": valorCedula.value,
        "nombre": valorNombre.value,
        "apellido": valorApellido.value,
        "salario": valorSalario.value,
        "fechaEntrada": valorFechaEntrada.value,
        "direccion": valorDireccion.value,
        "login": valorLogin.value,
        "pass": valorPass.value,
        "idHorario": valorHorario,
        "idRol": valorRol
    };
    $.ajax({
        data: parametros,
        url: 'ActualizarEmpleadoAction.php',
        type: 'post',
        success: function (response) {
            $("#resultado").html(response);
        }
    });
    
    obtenerEmpleados();
}

function obtenerEmpleados() {
    $.ajax({
        data: '',
        url: 'obtenerEmpleados.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}

function cargarEmpleados() {
    //Obtener los valores
    var cedula = document.getElementById("cbxEmpleado").value;
    var combo = document.getElementById("cbxEmpleado");
    var nombreEmpleado = combo.options[combo.selectedIndex].text;
    nombreEmpleado = nombreEmpleado.split("-");// Utilizamos el método split    

    //Cargar los valores en el cuadro de texto
    var txtCedula = document.getElementById("txtCedula");
    var txtNombre = document.getElementById("txtNombre");
    var txtApellido = document.getElementById("txtApellido");
    txtCedula.value = cedula;
    txtNombre.value = nombreEmpleado[1].trim();
    txtApellido.value = nombreEmpleado[2].trim();

}
