<?php

class licencia {
    
    public $tipoLicencia;
    public $fechaEmisionLicencia;
    public $fechaExpiracionLicencia;

    public function licencia($tipoLicencia, $fechaEmisionLicencia, $fechaExpiracionLicencia) {
        $this->tipoLicencia=$tipoLicencia;
        $this->fechaEmisionLicencia=$fechaEmisionLicencia;
        $this->fechaExpiracionLicencia=$fechaExpiracionLicencia;        
    }
}
