/******************* Metodos CRUD para HORARIO ***************************/
function insertarHorario() {
    //obtengo el dia elegido
    var dias = document.getElementsByName("rbnDias");

    for (var i = 0; i < dias.length; i++) {
        if (dias[i].checked) {
            var dia = dias[i].value;
        }
    }


    var idHorario = 0;
    var idEmpleado = document.getElementById("cbxEmpleado").value;
    var horaInicio = document.getElementById("cbxHoraInicio").value;
    var horaInicioMinuto = document.getElementById('cbxHoraInicioMinutos').value;
    var horaSalida = document.getElementById("cbxHoraSalida").value;
    var horaSalidaMinuto = document.getElementById('cbxHoraSalidaMinutos').value;

    var parametros = {
        "idHorario": idHorario.value,
        "idEmpleado": idEmpleado,
        "dias": dia,
        "horaInicio": horaInicio + ':' + horaInicioMinuto,
        "horaSalida": horaSalida + ':' + horaSalidaMinuto
    };

    $.ajax({
        data: parametros,
        url: 'insertarHorario.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpo los espacios
            obtenerHorarios();

            $("#resultado").html(response);
        }
    });

}

function borrarHorario() {
    var idHorario = document.getElementById("idHorario").value;

    var parametros = {
        "idHorario": idHorario
    };

    //para confirmar la opcion
    var confirmacion = confirm("¿ Desea eliminar este Horario ?");
    if (confirmacion === true) {
        $.ajax({
            data: parametros,
            url: 'borrarHorario.php',
            type: 'post',
            success: function (response) {
                obtenerHorarios();
                $("#resultado").html(response);
            }
        });
    }
}

function actualizarHorario() {
    var idHorario = document.getElementById("cbxHorarios").value;
    var dias = document.getElementById("txtDias");
    var horaInicio = document.getElementById("txtHoraInicio");
    var horaSalida = document.getElementById("txtHoraSalida");

    var parametros = {
        "idHorario": idHorario,
        "dias": dias.value,
        "horaInicio": horaInicio.value,
        "horaSalida": horaSalida.value
    };

    $.ajax({
        data: parametros,
        url: 'actualizarHorario.php',
        type: 'post',
        success: function (response) {
            $("#txtDias").val("");
            $("#txtHoraInicio").val("");
            $("#txtHoraSalida").val("");
            obtenerHorarios();
            $("#resultado").html(response);
        }
    });
}

function obtenerHorarios() {
    var idEmpleado = document.getElementById("cbxEmpleado").value;

    var parametros = {
        "idEmpleado": idEmpleado
    };

    $.ajax({
        data: parametros,
        url: 'obtenerHorarios.php',
        type: 'post',
        success: function (response) {
            $("#listaHorarios").html(response);
        }
    });
}

function cargarHorarios() {
    //Obtener los valores
    var idHorario = document.getElementById("cbxHorarios").value;
    var combo = document.getElementById("cbxHorarios");
    var dias = combo.options[combo.selectedIndex].text;

    /* HACER UN SPLIT PARA SACER LOS VALORES */

    dias = dias.split("-");// Utilizamos el método split

    //Cargar los valores en el cuadro de texto
    var txtDias = document.getElementById("txtDias");
    txtDias.value = dias[0].trim();

    var txtHoraInicio = document.getElementById("txtHoraInicio");
    txtHoraInicio.value = dias[1].trim();

    var txtHoraSalida = document.getElementById("txtHoraSalida");
    txtHoraSalida.value = dias[2].trim();
}

function obtenerEmpleadosHorario() {
    $.ajax({
        data: '',
        url: 'obtenerEmpleadosHorario.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}


