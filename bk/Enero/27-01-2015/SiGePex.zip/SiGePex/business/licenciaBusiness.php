<?php
include_once 'data/licenciaData.php';
class licenciaBusiness {

    //variables regarding composition
    private $licenciaData;

    public function licenciaBusiness() {
        $this->licenciaData = new licenciaData();
    }

    public function insertarEmpleado($identificacionEmpleado, $objLicenciaEmleado) {
        $resultado = $this->licenciaData->insertarLicencia($identificacionEmpleado, $objLicenciaEmleado);
        return $resultado;
    }

    public function actualizarLicencia($identificacionEmpleado, $objLicenciaEmleado) {
        $resultado = $this->licenciaData->actualizarLicencia($identificacionEmpleado, $objLicenciaEmleado);
        return $resultado;
    }

    public function eliminarLicencia($identificacionEmpleado, $tipoLicencia) {
        $resultado = $this->licenciaData->eliminarLicencia($identificacionEmpleado, $tipoLicencia);
        return $resultado;
    }

    public function buscarLicencia($identificacionEmpleado, $objLicenciaEmleado) {
        $resultado = $this->licenciaData->buscarLicencia($identificacionEmpleado, $objLicenciaEmleado);
        return $resultado;
    }

    public function buscarLicenciasEmpleado($identificacionEmpleado) {
        $resultado = $this->licenciaData->buscarLicenciasEmpleado($identificacionEmpleado);
        return $resultado;
    }
    public function obtenerLicencias() {
        $resultado = $this->licenciaData->obtenerLicencias();
        return $resultado;
    }

}
