
function mascaraCedula() {
    $("#txtCedula").mask("9-9999-9999", {placeholder: "#-####-####"});

//    var valor = document.getElementById("cbxTipo").value;
//    if (valor == 1) {
//        $("#identificacion").mask("9-9999-9999", {placeholder: "#-####-####"});
//    }
//    if (valor == 2) {
//        $("#identificacion").mask("99999999999", {placeholder: "############"});
//    }
//        <select id="cbxTipo" onchange="mascaraCedula();">
//            <option value="1">Nacional</option>
//            <option value="2">Extrangero</option>
//        </select>


}


