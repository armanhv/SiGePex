<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>RapiServicios</title>     
        <script type="text/javascript" src="../../js/ajaxHorario.js"></script>    
        <script type="text/javascript" src="../../js/jquery.js"></script>    
    </head>

    <body style="" onload="obtenerHorarios();
            obtenerEmpleadosHorario()">
        <div style="margin-left: 500px">
            <p><font size=6>Módulo Horario</font></p>

            <label for="Empleado">Eliga un Empleado:</label>
            <span id="empleados"></span><br>

            <table>
                <tr>
                    <td><label for="Dias">Días de Trabajo:&nbsp;&nbsp;</label></td>
                    <td>
                        <select name="cbxDias" id="cbxDias" >
                            <option value="lunes">Lunes</option>
                            <option value="martes">Martes</option>
                            <option value="miercoles">Miércoles</option>
                            <option value="jueves">Jueves</option>
                            <option value="viernes">Viernes</option>
                            <option value="sabado">Sábado</option>
                            <option value="domingo">Domingo</option>
                        </select>
                    </td>
                    <td><label for="HoraInicio">Hora Inicio:</label></td>
                    <td>
                        <select name="cbxHoraInicio" id="cbxHoraInicio" >
                            <option value="01:00">01:00</option>
                            <option value="02:00">02:00</option>
                            <option value="03:00">03:00</option>
                            <option value="04:00">04:00</option>
                            <option value="05:00">05:00</option>
                            <option value="06:00">06:00</option>
                            <option value="07:00">07:00</option>
                            <option value="08:00">08:00</option>
                            <option value="09:00">09:00</option>
                            <option value="10:00">10:00</option>
                            <option value="11:00">11:00</option>
                            <option value="12:00">12:00</option>
                        </select>
                    </td>
                    <td>
                        <input type="radio" id="radioHoraIni" name="horaIni" value="am">am<br>
                        <input type="radio" id="radioHoraIni" name="horaIni" value="pm">pm
                    </td>

                    <td><label for="HoraSalida">Hora de salida:</label></td>
                    <td>
                        <select name="cbxHoraInicio" id="cbxHoraInicio" >
                            <option value="01:00">01:00</option>
                            <option value="02:00">02:00</option>
                            <option value="03:00">03:00</option>
                            <option value="04:00">04:00</option>
                            <option value="05:00">05:00</option>
                            <option value="06:00">06:00</option>
                            <option value="07:00">07:00</option>
                            <option value="08:00">08:00</option>
                            <option value="09:00">09:00</option>
                            <option value="10:00">10:00</option>
                            <option value="11:00">11:00</option>
                            <option value="12:00">12:00</option>
                        </select>
                    </td>
                    <td>
                        <input type="radio" id="radioHoraSali" name="horaSali" value="am">am<br>
                        <input type="radio" id="radioHoraSali" name="horaSali" value="pm">pm
                    </td>
                </tr>
                <tr>
                    <td><input type="button" value="Insertar" onclick="insertarHorario()">&nbsp;&nbsp;</td>
                    <td><input type="button" value="Actualizar" onclick="actualizarHorario()">&nbsp;&nbsp;</td>
                    <td><input type="button" value="Borrar" onclick="borrarHorario()">&nbsp;&nbsp;</td>
                </tr>
            </table><br>

            <span id="resultado"></span><br>
            
            <span id="horarios"></span><br>
        </div>
    </body>
</html>
