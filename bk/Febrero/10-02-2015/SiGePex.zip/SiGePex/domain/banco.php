<?php

class banco {

    //Atributos del objeto
    public $idBanco;
    public $nombreBanco;

    public function banco($idBanco, $nombreBanco) {
        $this->idBanco = $idBanco;
        $this->nombreBanco = $nombreBanco;
    }

}


