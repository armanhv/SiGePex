<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <a href="presentation/rol/rolPresentacion.php">Rol</a>
        <br >
        <a href="presentation/horario/horarioPresentacion.php">Horario</a>
        <br>
        <a href="presentation/empleado/empleadoPresentacion.php">Empleado</a>
        <br>
        <a href="presentation/salario/salarioPresentacion.php">Salario</a>
        <br>
        <a href="presentation/pagoPeriodo/pagoPeriodoPresentacion.php">Pago Periodo</a>
        <br>
        <a href="presentation/cuenta/cuentaPresentacion.php">Cuenta</a>
        <br>
        <a href="presentation/banco/bancoPresentacion.php">Banco</a>
        <br>
        <a href="presentation/cliente/clientePresentacion.php">Cliente</a>
        <br>
        <a href="presentation/ingresos/ingresosPresentacion.php">Ingreso</a>
        <br>
        <a href="presentation/cuentasPorCobrar/cuentasPorCobrarPresentacion.php">Cuentas por cobrar</a>
        <br>
        <a href="presentation/morosidad/morosidadPresentacion.php">Morosidad</a>
        <br>
        <a href="presentation/morosidad/morosidadRangoFechasPresentacion.php">Busqueda de Morosos</a>
        <br>
        <a href="presentation/tipoServicio/tipoServicioPresentacion.php">Tipo de Servicio</a>
        <br>
        <a href="presentation/servicio/servicioPresentacion.php">Servicio</a>
        <br>
    </body>
</html>