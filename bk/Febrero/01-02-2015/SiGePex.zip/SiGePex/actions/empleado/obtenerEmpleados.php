<?php

include '../../business/empleadoBusiness.php';

//comunicacion con Business
$bancoBusiness = new EmpleadoBusiness();
$listaEmpleados = $bancoBusiness->obtenerEmpleados();

echo '<SELECT onClick="buscarEmpleado();obtenerTelefonosEmpleado();obtenerLicenciasEmpleado();recarga()" name="cbxEmpleado" id="cbxEmpleado" size=1>';
echo '<option value="0" selected>Seleccione un empleado</option>';
foreach ($listaEmpleados as $currentEmpleado) {

    $idEmpleado = $currentEmpleado->idEmpleado;
    $idCedula = $currentEmpleado->cedulaEmpleado;
    $nombreEmpleado = $currentEmpleado->nombreEmpleado . ' ' . $currentEmpleado->primerApellidoEmpleado . ' ' . $currentEmpleado->segundoApellidoEmpleado;
    echo '<option value=' . $idEmpleado . '>' . $idCedula . ' - ' . $nombreEmpleado . '</option>';
}



