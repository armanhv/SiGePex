<?php

class rol {

    //Atributos del objeto
    public $idRol;
    public $nombreRol;

    public function rol($idRol, $nombreRol) {
        $this->idRol = $idRol;
        $this->nombreRol = $nombreRol;
    }

}
