<?php
include '../../business/cuentasPorCobrarBusiness.php';

$cuentasPorCobrarBusiness=new cuentasPorCobrarBusiness();
$cuentasPorCobrarBusiness->verificarCuentasPorCobrarFechaPago();
