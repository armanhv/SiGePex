<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <a href="presentation/rol/rolPresentacion.php">Rol</a>
        <br >
        <a href="presentation/horario/horarioPresentacion.php">Horario</a>
        <br>
        <a href="presentation/empleado/EmpleadoPresentacion.php">Empleado</a>
        <br>
        <a href="presentation/salario/salarioPresentacion.php">Salario</a>
        <br>
        <a href="presentation/pagoPeriodo/pagoPeriodoPresentacion.php">Pago Periodo</a>
        <br>
        <a href="presentation/cuenta/cuentaPresentacion.php">Cuenta</a>
        <br>
        <a href="presentation/cliente/clientePresentacion.php">cliente</a>
    </body>
</html>