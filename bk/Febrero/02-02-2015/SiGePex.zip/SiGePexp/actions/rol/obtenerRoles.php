<?php

include '../../business/rolBusiness.php';

//comunicacion con Business
$telefonoBusiness = new rolBusiness();
$listaTelefonos = $telefonoBusiness->getRoles();

echo '<SELECT onChange="cargarRoles()" NAME="cbxRoles" id="cbxRoles" SIZE=1>';

foreach ($listaTelefonos as $currentRol) {

    $idRol = $currentRol->idRol;
    $nombreRol = $currentRol->nombreRol;

    echo '<option value=' . $idRol . '>' . $nombreRol . '</option>';
}