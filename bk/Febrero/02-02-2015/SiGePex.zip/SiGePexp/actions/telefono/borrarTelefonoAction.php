
<?php

include '../../business/telefonoBusiness.php';

$idTelefono = $_POST['idTelefono'];

//instancia de business
$telefonoBusiness = new telefonoBusiness();

//se elimina
$resultado = $telefonoBusiness->eliminarTelefono($idTelefono);

if ($resultado) {


    echo '<div id="dialog" title="Mensaje">';
    echo '<p>Se ha borrado correctamente</p></div>';
} else {


    echo '<div id="dialog" title="Error">';
    echo '<p>No se ha borrado</p>';
    echo ' </div>';
}
?> 
