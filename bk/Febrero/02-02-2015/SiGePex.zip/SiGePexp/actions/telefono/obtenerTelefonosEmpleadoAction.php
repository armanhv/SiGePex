<?php

include_once '../../business/telefonoBusiness.php';
include_once '../../business/empleadoBusiness.php';

$idEmpleado = $_POST['idEmpleado'];

if ($idEmpleado != 0)  {
    //comunicacion con Business
    $telefonoBusiness = new telefonoBusiness();
    $listaTelefonosEmpleado = $telefonoBusiness->buscarTelefonosEmpleado($idEmpleado);
    $empleadoBusiness = new empleadoBusiness();
    $empleado = $empleadoBusiness->buscarEmpleado($idEmpleado);
echo ' <h3>Agregar Telefonos</h3>
            <label for="rol">Numero de Telefono:&nbsp;&nbsp;</font></label>  
            <input type="text" size="1" name="num1" id="txtTelefonoNum1" maxlength="2" onkeyup="contar(this, num2)" />-
            <input type="text" size="1" name="num2" id="txtTelefonoNum2" maxlength="2" onkeyup="contar(this, num3)" />-
            <input type="text" size="1" name="num3" id="txtTelefonoNum3" maxlength="2" onkeyup="contar(this, num4)" />-
            <input type="text" size="1" name="num4" id="txtTelefonoNum4" maxlength="2" onkeyup="contar(this, num1)" />
            <input type="button" value="Insertar Telefono" onclick="insertarTelefono();">&nbsp;&nbsp;
            <input type="button" value="Modificar Telefono" onclick="actualizarTelefono()">&nbsp;&nbsp;
            <input type="button" value="Eliminar Telefono" onclick="eliminarTelefono()">&nbsp;&nbsp; <br>
             <span id="resultadoTelefono"></span>    <br>';
    echo '
        <table>
            <tr>                
                <td>Numeros de Telefono: &nbsp;&nbsp;&nbsp;</td>
            </tr>';

    foreach ($listaTelefonosEmpleado as $currentTelefono) {
        echo '
            <tr>
                <td><input type="radio" id="idTelefono" name="idTelefono" value="'.$currentTelefono->idTelefono.'" checked></td>
                <td><a>' . $currentTelefono->numeroTelefono . '</a></td>
            </tr>';
    }// fin foreach

    echo '
           
        </table>
    <br>    
    ';
}//fin de ELSE IF 