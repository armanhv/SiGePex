<?php

include '../../business/empleadoBusiness.php';

//comunicacion con Business
$licenciaBusiness = new EmpleadoBusiness();
$listaEmpleados = $licenciaBusiness->obtenerEmpleados();
echo '<SELECT onClick="buscarEmpleado();obtenerTelefonosEmpleado()" NAME="cbxEmpleado" id="cbxEmpleado" SIZE=1>';
echo '<option value=0>Seleccione un empleado</option>';
foreach ($listaEmpleados as $currentEmpleado) {

    $idEmpleado = $currentEmpleado->idEmpleado;
    $idCedula = $currentEmpleado->cedulaEmpleado;
    $nombreEmpleado = $currentEmpleado->nombreEmpleado . " " . $currentEmpleado->primerApellidoEmpleado . " " . $currentEmpleado->segundoApellidoEmpleado;

    echo '<option value=' . $idEmpleado . '>' . $nombreEmpleado . '</option>';
}



