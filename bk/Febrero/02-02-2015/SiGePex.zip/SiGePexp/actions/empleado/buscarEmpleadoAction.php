<?php

include '../../business/empleadoBusiness.php';

$empleadoBusiness = new empleadoBusiness();

$empleado = $empleadoBusiness->buscarEmpleado($_POST['id']);

header("Content-type: text/x-json");

echo json_encode($empleado);

exit();

?>