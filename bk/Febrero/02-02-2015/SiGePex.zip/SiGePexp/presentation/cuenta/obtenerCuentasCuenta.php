<?php

include '../../business/cuentaBusiness.php';

//comunicacion con Business
$cuentaBusiness = new cuentaBusiness();
$listaCuentas = $cuentaBusiness->obtenerCuentas();

echo '<SELECT onChange="cargarCuentas();" NAME="cbxCuentas" id="cbxCuentas" SIZE=1>';
echo '<option value=0>Elija una Cuenta</option>';

foreach ($listaCuentas as $currentCuenta) {

    echo '<option value=' . $currentCuenta->idCuenta . '>' . $currentCuenta->numeroCuenta . '</option>';
}

echo '</select>';
