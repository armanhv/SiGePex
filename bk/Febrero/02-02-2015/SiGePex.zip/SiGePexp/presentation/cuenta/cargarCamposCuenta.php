<?php

include '../../business/cuentaBusiness.php';

//los valores almacenados que se enviarion por el cliente
$idCuenta = $_POST['idCuenta'];

$cuentaBusiness = new cuentaBusiness(); //comunucacion con Business
$cuenta = $cuentaBusiness->buscarCuenta($idCuenta);

echo '

    <table>       
        <tr>
            <td><label for="numeroCuenta">Numero Cuenta:</label></td>
            <td><input type="text" value="' . $cuenta->numeroCuenta . '" name="txtNumeroCuenta" id="txtNumeroCuenta"><br></td>
        </tr>

        <tr>
            <td><label for="nombreBanco">Nombre Banco:</label></td>
            <td><input type="text" value="' . $cuenta->nombreBanco . '" name="txtNombreBanco" id="txtNombreBanco"><br></td>
        </tr>

        <tr>
            <td><label for="tipoCuenta">Tipo Cuenta:</label></td>
            <td> <select id="cbxTipoCuenta" name="cbxTipoCuenta">
                    <option value="' . $cuenta->tipoCuenta . '">' . $cuenta->tipoCuenta . '</option>
            </select></td>
        </tr>
        <tr>
            <td><label for="numeroSimpe">Numero Simpe:</label></td>
            <td><input type="text" value="' . $cuenta->numeroSimpe . '" name="txtnumeroSimpe" id="txtnumeroSimpe"><br></td>
        </tr>

        <tr>
            <td><input type="button" value="Insertar" onclick="insertarCuenta()">&nbsp;&nbsp;</td>
            <td><input type="button" value="Actualizar" onclick="actualizarCuenta()">&nbsp;&nbsp;</td>
            <td><input type="button" value="Borrar" onclick="borrarCuenta()">&nbsp;&nbsp;</td>
        </tr>
    </table>
                ';
?>
