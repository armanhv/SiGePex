<?php
include_once 'BaseDatos.php';
include_once '../../domain/empleado.php';
include '../../utilidades/utilidadesGenerales.php';

class empleadoData {   

    private $objConexionBaseDatos;
	private $utilidad;
	
    public function empleadoData(){
        $this->objConexionBaseDatos=new BaseDatos();
        $this->utilidad=new utilidadesGenerales($this->objConexionBaseDatos);
    }      
    
    
    public function insertarEmpleado($empleado){
        $query = "insert into tbempleado values (".$this->utilidad->generarIdAutoIncremental('idEmpleado','tbempleado').",'" . $empleado->cedulaEmpleado . "', '" . $empleado->nombreEmpleado . "', '"
            . $empleado->primerApellidoEmpleado. "', '" . $empleado->segundoApellidoEmpleado. "', '" . $empleado->fechaNacimientoEmpleado. "', '"
            . $empleado->emailEmpleado. "', '" . $empleado->direccionEmpleado. "', '" . $empleado->loginEmpleado. "', '"
            . $empleado->passwordEmpleado."',".$empleado->cantidadHorasLaborales.",".$empleado->costoHoraExtra. ", "
            . $empleado->tiempoAlmuerzo. ",". $empleado->objRol->idRol. ");";
        $result = mysqli_query($this->objConexionBaseDatos->abrirConexion(), $query);
        $this->objConexionBaseDatos->cerrarConexion();
        if($result){
            return true;
        }else{
            return false;
        } 
    }
    
    
    public function actualizarEmpleado($empleado) { 
        $query = "update tbEmpleado set cedulaEmpleado='".$empleado->cedulaEmpleado."', nombreEmpleado='" . $empleado->nombreEmpleado . "', primerApellidoEmpleado= '" 
                . $empleado->primerApellidoEmpleado . "', segundoApellidoEmpleado= '" . $empleado->segundoApellidoEmpleado . "', fechaNacimiento= '" 
                . $empleado->fechaNacimientoEmpleado . "', emailEmpleado= '" . $empleado->emailEmpleado . "', direccionEmpleado= '" . $empleado->direccionEmpleado 
                . "', loginEmpleado='" . $empleado->loginEmpleado. "', passwordEmpleado='" . $empleado->passwordEmpleado
                . "', cantidadHorasLaborales=".$empleado->cantidadHorasLaborales. ", costoHoraExtra=".$empleado->costoHoraExtra. ", tiempoAlmuerzo=".$empleado->tiempoAlmuerzo
                .", idRolEmpleado=" . $empleado->objRol->idRol. " where idEmpleado=". $empleado->idEmpleado .";";        
        
        $result = mysqli_query($this->objConexionBaseDatos->abrirConexion(), $query);
        $this->objConexionBaseDatos->cerrarConexion();

        if($result){
            return true;
        }else{
            return false;
        }
        
    }
    
    public function eliminarEmpleado($idEmpleado) {
        $query = "delete from tbEmpleado where idEmpleado=" .$idEmpleado .";";
        $result = mysqli_query($this->objConexionBaseDatos->abrirConexion(), $query);
        $this->objConexionBaseDatos->cerrarConexion();
        if($result){
            return true;
        }else{
            return false;
        }
    }    
    
    public function buscarEmpleado($identificacionEmpleado) {  
        $query =  "select* from tbEmpleado where(idEmpleado =" . $identificacionEmpleado . ")";     
        $resulGeneral = mysqli_query($this->objConexionBaseDatos->abrirConexion(), $query);
        
        $row = $resulGeneral->fetch_array();
        
        $empleado = new empleado($row['idEmpleado'],$row['cedulaEmpleado'],
                    $row['nombreEmpleado'],$row['primerApellidoEmpleado'], $row['segundoApellidoEmpleado'], 
                    $row['fechaNacimiento'], $row['emailEmpleado'], $row['direccionEmpleado'],
                    $row['loginEmpleado'], $row['passwordEmpleado'], $row['cantidadHorasLaborales'],
                    $row['costoHoraExtra'],$row['tiempoAlmuerzo'], $row['idRolEmpleado']);
        
        $this->objConexionBaseDatos->cerrarConexion();
        return $empleado;
    }

    public function obtenerEmpleados(){
        $query ="select* from tbempleado";
        $result = mysqli_query($this->objConexionBaseDatos->abrirConexion(), $query);
        $arrayEmpleados = [];

        while ($row = mysqli_fetch_array($result)) {
            $empleadoActual = new empleado($row['idEmpleado'],$row['cedulaEmpleado'],
                    $row['nombreEmpleado'],$row['primerApellidoEmpleado'], $row['segundoApellidoEmpleado'], 
                    $row['fechaNacimiento'], $row['emailEmpleado'], $row['direccionEmpleado'],
                    $row['loginEmpleado'], $row['passwordEmpleado'], $row['cantidadHorasLaborales'],
                    $row['costoHoraExtra'],$row['tiempoAlmuerzo'], $row['idRolEmpleado']);       
            array_push($arrayEmpleados, $empleadoActual);
        }
        $this->objConexionBaseDatos->cerrarConexion();
        return $arrayEmpleados;
        
    }   
    
}
