/******************* Metodos CRUD para telefono ***************************/
function insertarTelefono() {
    var parametros = {
        "identificacionEmpleadoTelefono": $('#cbxEmpleado').val(),
        "numeroTelefono": obtenerTelefono()

    };

    $.ajax({
        data: parametros,
        url: '../../actions/telefono/insertarTelefono.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerTelefonos();
            $("#resultadoTelefono").html(response);
        }
    });
    obtenerTelefonosEmpleado();
}

function actualizarTelefono() {
    var idTelefono = $('input:radio[name=idTelefono]:checked').val();
    var telefonoNuevo=obtenerTelefono();
    var confirmacion = confirm("¿ Desea actualizar este telefono?");
    if (confirmacion) {
        var parametros = {
            "idTelefono": idTelefono,
            "nuevoTelefono":telefonoNuevo
        };
        $.ajax({
            data: parametros,
            url: '../../actions/telefono/actualizarTelefonoAction.php',
            type: 'post',
            success: function (response) {
                $("#resultadoTelefono").html(response);
            }
        });
        obtenerTelefonosEmpleado();
    }
}

function eliminarTelefono() {
    var idTelefono = $('input:radio[name=idTelefono]:checked').val();
    var confirmacion = confirm("¿ Desea eliminar este telefono? id:" + idTelefono);
    if (confirmacion) {
        var parametros = {
            "idTelefono": idTelefono
        };
        $.ajax({
            data: parametros,
            url: '../../actions/telefono/borrarTelefonoAction.php',
            type: 'post',
            success: function (response) {
                $("#resultadoTelefono").html(response);
            }
        });
        obtenerTelefonosEmpleado();
    }
}
function obtenerTelefonosEmpleado() {
    var idEmpleado = document.getElementById("cbxEmpleado").value;

    var parametros = {
        "idEmpleado": idEmpleado
    };

    $.ajax({
        data: parametros,
        url: '../../actions/telefono/obtenerTelefonosEmpleadoAction.php',
        type: 'post',
        success: function (response) {
            $("#listaTelefonos").html(response);
        }
    });
}

