/******************* Metodos CRUD para cliente ***************************/
function insertarCliente() {

    var idCliente = 0;

    var parametros = {
        "idCliente": idCliente.value,
        "nombreCliente": $('#txtNombreCliente').val(),
        "primerApellido": $('#txtPrimerApellido').val(),
        "segundoApellido": $('#txtSegundoApellido').val(),
	"direccion": $('#txtDireccion').val()
    };

    $.ajax({
        data: parametros,
        url: '../../actions/cliente/insertarCliente.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerClientes();
            $("#resultado").html(response);
        }
    });

}

function actualizarCliente() {

    var idCliente = document.getElementById("cbxCliente").value;
    var parametros = {
        "idCliente": idCliente,
        "nombreCliente": $('#txtNombreCliente').val(),
        "primerApellido": $('#txtPrimerApellido').val(),
        "segundoApellido": $('#txtSegundoApellido').val(),
	"direccion": $('#txtDireccion').val()
    };

    $.ajax({
        data: parametros,
        url: '../../actions/cliente/actualizarClientes.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerClientes();
            $("#resultado").html(response);
        }
    });
}

function borrarCliente() {
    var idCliente = document.getElementById("cbxCliente").value;

    var parametros = {
        "idCliente": idCliente
    };

    $.ajax({
        data: parametros,
        url: '../../.actions/cliente/borrarCliente.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpan los espacios
            $('input[type=text]').val("");
            obtenerClientes();
            $("#resultado").html(response);
        }
    });
}

function obtenerClientes() {
    $.ajax({
        data: '',
        url: '../../actions/cliente/obtenerCliente.php',
        type: 'post',
        success: function (response) {
            $("#clientes").html(response);
        }


    });
}

function cargarCliente() {
    //Obtener los valores
    var idCliente = document.getElementById("cbxCliente").value;

    var parametros = {
        "idCliente": idCliente
    };

    $.ajax({
        data: parametros,
        url: '../../actions/cliente/cargarClientes.php',
        type: 'post',
        success: function (response) {
            $("#tablaCliente").html(response);
        }
    });
}

