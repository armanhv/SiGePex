/******************* Metodos CRUD para ROL ***************************/
function insertarRol() {
    var idRol = 0;
    var nombreRol = document.getElementById("txtNombreRol");

    var parametros = {
        "idRol": idRol.value,
        "nombreRol": nombreRol.value
    };

    $.ajax({
        data: parametros,
        url: '../../actions/rol/insertarRol.php',
        type: 'post',
        success: function (response) {
            //se recarga el combo y limpo los espacios
            $("#txtNombreRol").val("");
            obtenerRoles();
            $("#resultado").html(response);
        }
    });

}

function borrarRol() {
    var idRol = document.getElementById("cbxRoles").value;

    var parametros = {
        "idRol": idRol
    };

    $.ajax({
        data: parametros,
        url: '../../actions/rol/borrarRol.php',
        type: 'post',
        success: function (response) {
            $("#txtNombreRol").val("");
            obtenerRoles();
            $("#resultado").html(response);
        }
    });
}

function actualizarRol() {
    var idRol = document.getElementById("cbxRoles").value;
    var nombreRol = document.getElementById("txtNombreRol");

    var parametros = {
        "idRol": idRol,
        "nombreRol": nombreRol.value
    };

    $.ajax({
        data: parametros,
        url: '../../actions/rol/actualizarRol.php',
        type: 'post',
        success: function (response) {
            $("#txtNombreRol").val("");
            obtenerRoles();
            $("#resultado").html(response);
        }
    });
}

function obtenerRoles() {
    $.ajax({
        data: '',
        url: '../../actions/rol/obtenerRoles.php',
        type: 'post',
        success: function (response) {
            $("#roles").html(response);
        }
    });
}

function cargarRoles() {
    //Obtener los valores
    var idRol = document.getElementById("cbxRoles").value;
    var combo = document.getElementById("cbxRoles");
    var nombreRol = combo.options[combo.selectedIndex].text;

    //Cargar los valores en el cuadro de texto
    var txtNombreRol = document.getElementById("txtNombreRol");
    txtNombreRol.value = nombreRol;
}