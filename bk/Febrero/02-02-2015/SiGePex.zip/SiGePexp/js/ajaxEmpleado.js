
function eliminarEmpleado() {
    var valorIdEmpleado = document.getElementById("cbxEmpleado").value;
    var parametros = {
        "idEmpleado": valorIdEmpleado
    };
    $.ajax({
        data: parametros,
        url: '../../actions/empleado/eliminarEmpleadoAction.php',
        type: 'post',
        success: function (response) {
            $("#resultado").html(response);
        }
    });
    obtenerEmpleados();
    obtenerTelefonosEmpleado();
    limpiarCampos();
}

function insertarEmpleado() {
    if (validarEmail()) {
        var valorCedula = document.getElementById("txtCedula");
        var valorNombre = document.getElementById("txtNombre");
        var valorPrimerApellido = document.getElementById("txtPrimerApellido");
        var valorSegundoApellido = document.getElementById("txtSegundoApellido");
        var valorFechaNacimiento = document.getElementById("txtFechaNacimiento");
        var valorEmailEmpleado = document.getElementById("txtEmailEmpleado");
        var valorDireccionEmpleado = document.getElementById("txtDireccionEmpleado");
        var valorLogin = document.getElementById("txtLogin");
        var valorPass = document.getElementById("txtPassword");
        var valorCantidadHorasLaborales = document.getElementById("txtCantidadHorasLaborales");
        var valorCostoHoraExtra = document.getElementById("txtCostoHoraExtra");
        var valorTiempoAlmuerzo = document.getElementById("txtTiempoAlmuerzo");
        var valorRol = document.getElementById("cbxRoles").value;

        var parametros = {
            "cedula": valorCedula.value,
            "nombre": valorNombre.value,
            "primerApellido": valorPrimerApellido.value,
            "segundoApellido": valorSegundoApellido.value,
            "fechaNacimiento": valorFechaNacimiento.value,
            "emailEmpleado": valorEmailEmpleado.value,
            "direccionEmpleado": valorDireccionEmpleado.value,
            "login": valorLogin.value,
            "pass": valorPass.value,
            "cantidadHoras": valorCantidadHorasLaborales.value,
            "costoHoraExtra": valorCostoHoraExtra.value,
            "tiempoAlmuerzo": valorTiempoAlmuerzo.value,
            "idRol": valorRol
        };

        $.ajax({
            data: parametros,
            url: '../../actions/empleado/insertarEmpleadoAction.php',
            type: 'post',
            success: function (response) {
                $("txtCedula").val("");
                $("txtNombre").val("");
                $("txtPrimerApellido").val("");
                $("txtSegundoApellido").val("");
                $("txtFechaNacimiento").val("");
                $("txtEmailEmpleado").val("");
                $("txtDireccionEmpleado").val("");
                $("txtLogin").val("");
                $("txtPassword").val("");
                $("txtCantidadHorasLaborales").val("");
                $("txtCostoHoraExtra").val("");
                $("txtTiempoAlmuerzo").val("");
                obtenerEmpleados();
                obtenerTelefonosEmpleado();
                $("#resultado").html(response);
            }
        });
    }

}

function actualizarEmpleado() {
    if (validarEmail()) {
        var valorIdEmpleado = document.getElementById("cbxEmpleado").value;
        var valorCedula = document.getElementById("txtCedula");
        var valorNombre = document.getElementById("txtNombre");
        var valorPrimerApellido = document.getElementById("txtPrimerApellido");
        var valorSegundoApellido = document.getElementById("txtSegundoApellido");
        var valorFechaNacimiento = document.getElementById("txtFechaNacimiento");
        var valorEmailEmpleado = document.getElementById("txtEmailEmpleado");
        var valorDireccionEmpleado = document.getElementById("txtDireccionEmpleado");
        var valorLogin = document.getElementById("txtLogin");
        var valorPass = document.getElementById("txtPassword");
        var valorCantidadHorasLaborales = document.getElementById("txtCantidadHorasLaborales");
        var valorCostoHoraExtra = document.getElementById("txtCostoHoraExtra");
        var valorTiempoAlmuerzo = document.getElementById("txtTiempoAlmuerzo");
        var valorRol = document.getElementById("cbxRoles").value;
        var parametros = {
            "idEmpleado": valorIdEmpleado,
            "cedula": valorCedula.value,
            "nombre": valorNombre.value,
            "primerApellido": valorPrimerApellido.value,
            "segundoApellido": valorSegundoApellido.value,
            "fechaNacimiento": valorFechaNacimiento.value,
            "emailEmpleado": valorEmailEmpleado.value,
            "direccionEmpleado": valorDireccionEmpleado.value,
            "login": valorLogin.value,
            "pass": valorPass.value,
            "cantidadHoras": valorCantidadHorasLaborales.value,
            "costoHoraExtra": valorCostoHoraExtra.value,
            "tiempoAlmuerzo": valorTiempoAlmuerzo.value,
            "idRol": valorRol
        };
        $.ajax({
            data: parametros,
            url: '../../actions/empleado/actualizarEmpleadoAction.php',
            type: 'post',
            success: function (response) {
                $("#resultado").html(response);
            }
        });
        obtenerEmpleados();
        obtenerTelefonosEmpleado();
        limpiarCampos();
    }
}

function obtenerEmpleados() {
    $.ajax({
        data: '',
        url: '../../actions/empleado/obtenerEmpleados.php',
        type: 'post',
        success: function (response) {
            $("#empleados").html(response);
        }
    });
}

function buscarEmpleado() {
    var iID = document.getElementById("cbxEmpleado").value;
    
    $.ajax({
        url: "../../actions/empleado/buscarEmpleadoAction.php",
        type: "POST",
        datatype: "JSON",
        data: {
            valueAction: 1,
            id: iID
        },
        success: function (msg)
        {
            var txtCedula = document.getElementById("txtCedula");
            var txtNombre = document.getElementById("txtNombre");
            var txtPrimerApellido = document.getElementById("txtPrimerApellido");
            var txtSegundoApellido = document.getElementById("txtSegundoApellido");
            var txtFechaNacimiento = document.getElementById("txtFechaNacimiento");
            var txtEmailEmpleado = document.getElementById("txtEmailEmpleado");
            var txtDireccionEmpleado = document.getElementById("txtDireccionEmpleado");
            var txtLogin = document.getElementById("txtLogin");
            var txtPass = document.getElementById("txtPassword");
            var txtCantidadHorasLaborales = document.getElementById("txtCantidadHorasLaborales");
            var txtCostoHoraExtra = document.getElementById("txtCostoHoraExtra");
            var txtTiempoAlmuerzo = document.getElementById("txtTiempoAlmuerzo");
            var cbxRol = document.getElementById("cbxRoles");
            
            txtCedula.value = msg.cedulaEmpleado;
            txtNombre.value = msg.nombreEmpleado;
            txtPrimerApellido.value = msg.primerApellidoEmpleado;
            txtSegundoApellido.value = msg.segundoApellidoEmpleado;
            txtFechaNacimiento.value = msg.fechaNacimientoEmpleado;
            txtEmailEmpleado.value = msg.emailEmpleado;
            txtDireccionEmpleado.value = msg.direccionEmpleado;
            txtLogin.value = msg.loginEmpleado;
            txtPass.value = msg.passwordEmpleado;
            txtCantidadHorasLaborales.value = msg.cantidadHorasLaborales;
            txtCostoHoraExtra.value = msg.costoHoraExtra;
            txtTiempoAlmuerzo.value = msg.tiempoAlmuerzo;
        }
    });
}


function  limpiarCampos() {
    var txtCedula = document.getElementById("txtCedula");
    var txtNombre = document.getElementById("txtNombre");
    var txtPrimerApellido = document.getElementById("txtPrimerApellido");
    var txtSegundoApellido = document.getElementById("txtSegundoApellido");
    var txtFechaNacimiento = document.getElementById("txtFechaNacimiento");
    var txtEmailEmpleado = document.getElementById("txtEmailEmpleado");
    var txtDireccionEmpleado = document.getElementById("txtDireccionEmpleado");
    var txtLogin = document.getElementById("txtLogin");
    var txtPass = document.getElementById("txtPassword");
    var txtCantidadHorasLaborales = document.getElementById("txtCantidadHorasLaborales");
    var txtCostoHoraExtra = document.getElementById("txtCostoHoraExtra");
    var txtTiempoAlmuerzo = document.getElementById("txtTiempoAlmuerzo");
    var cbxRol = document.getElementById("cbxRoles");
    txtCedula.value = "";
    txtNombre.value = "";
    txtPrimerApellido.value = "";
    txtSegundoApellido.value = "";
    txtFechaNacimiento.value = "";
    txtEmailEmpleado.value = "";
    txtDireccionEmpleado.value = "";
    txtLogin.value = "";
    txtPass.value = "";
    txtCantidadHorasLaborales.value = "";
    txtCostoHoraExtra.value = "";
    txtTiempoAlmuerzo.value = "";
}